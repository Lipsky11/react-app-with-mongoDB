import React from 'react';
import './App.css';
import UsersComponent from './UsersComponent'


function App() {
  return (
    <div className="App">
      <UsersComponent/>
  </div>
  );
}

export default App;
